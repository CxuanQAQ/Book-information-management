package book;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

import book.db.Database;

import java.util.*;
import java.sql.*;

public class ReaderIQ extends JInternalFrame {
	JLabel lb1 = new JLabel("������Ϣ��ѯ");
	JLabel lb2 = new JLabel("ID��");
	JLabel lb3 = new JLabel("������");
	JTextField txt1 = new JTextField(10);
	JTextField txt2 = new JTextField(10);
	JButton btn1 = new JButton("��ѯ");
	JTable table;
	DefaultTableModel dtm;
	String columns[] = { "ID", "����", "�绰" };

	public ReaderIQ() {
		setTitle("������Ϣ��ѯ");
		dtm = new DefaultTableModel();
		table = new JTable(dtm);
		JScrollPane sl = new JScrollPane(table);
		dtm.setColumnCount(6);
		dtm.setColumnIdentifiers(columns);
		getContentPane().setLayout(null);
		lb1.setBounds(200, 10, 300, 30);
		lb1.setFont(new Font("����", Font.BOLD, 24));
		getContentPane().add(lb1);
		Font f = new Font("����", Font.PLAIN, 12);
		lb2.setBounds(10, 60, 80, 25);
		lb2.setFont(f);
		getContentPane().add(lb2);
		txt1.setBounds(80, 60, 80, 23);
		txt1.setFont(f);
		getContentPane().add(txt1);
		lb3.setBounds(10, 90, 80, 25);
		lb3.setFont(f);
		getContentPane().add(lb3);
		txt2.setBounds(80, 90, 80, 23);
		txt2.setFont(f);
		getContentPane().add(txt2);
		btn1.setBounds(90, 130, 60, 25);
		btn1.setFont(f);
		getContentPane().add(btn1);
		txt1.setBorder(BorderFactory.createLineBorder(Color.black));
		txt2.setBorder(BorderFactory.createLineBorder(Color.black));
		btn1.setBorder(BorderFactory.createRaisedBevelBorder());
		sl.setBorder(BorderFactory.createLineBorder(Color.black));
		Database.joinDB();
		String scEPIQ = "select * from reader";
		if (Database.query(scEPIQ)) {
			System.out.println(scEPIQ);
			try {
				while (Database.rs.next()) {
					String id = ("" + Database.rs.getInt("id"));
					String name = Database.rs.getString("name");
					String tel = Database.rs.getString("tel");
					Vector v = new Vector();
					v.add(id);
					v.add(name);
					v.add(tel);
					dtm.addRow(v);
				}
			} catch (Exception eEPIQ) {
			}
		}
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("��ѯ��ť�¼�ִ��");
				String sEPIQ;
				int rc = dtm.getRowCount();
				for (int i = 0; i < rc; i++) {
					dtm.removeRow(0);
				}
				if (txt1.getText().equals("") && txt2.getText().equals("")) {
					sEPIQ = "select * from reader";
				} else if (txt2.getText().equals("")) {
					sEPIQ = "select * from reader where id = " + txt1.getText() + "";
				} else {
					sEPIQ = "select * from reader where id = '" + txt1.getText() + "' or name like '%"
							+ txt2.getText() + "%'";
				}
				System.out.println(sEPIQ);
				if (Database.query(sEPIQ)) {
					System.out.println(sEPIQ);
					try {
						while (Database.rs.next()) {
							String id = ("" + Database.rs.getInt("id"));
							String name = Database.rs.getString("name");
							String tel = Database.rs.getString("tel");
							Vector v = new Vector();
							v.add(id);
							v.add(name);
							v.add(tel);
							dtm.addRow(v);
						}
					} catch (Exception eEPIQ) {
					}
				}
			}
		});
		sl.setBounds(180, 60, 425, 290);
		getContentPane().add(sl);
		setSize(630, 400);
		this.setClosable(true);
		setVisible(true);
	}
}