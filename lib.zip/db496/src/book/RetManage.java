package book;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import book.db.Database;

import java.sql.*;

public class RetManage extends JInternalFrame {
	JLabel lbid = new JLabel("ID��");
	JLabel lbreaderid = new JLabel("���߱�ţ�");
	JLabel lbbookid = new JLabel("ͼ���ţ�");
	JLabel lbrdate = new JLabel("�黹���ڣ�");
	JTextField tid = new JTextField();
	JTextField treaderid = new JTextField();
	JTextField tbookid = new JTextField();
	JTextField trdate = new JTextField();
	JButton btright = new JButton("<<");
	JButton btleft = new JButton(">>");
	JButton btdelet = new JButton("ɾ��");
	JButton btamend = new JButton("�޸�");
	JButton btsave = new JButton("����");
	JButton btadd = new JButton("����");

	public RetManage() {
		setTitle("�黹����!");
		btsave.setEnabled(false);
		getContentPane().setLayout(null);
		Font f = new Font("������", 0, 14);
		btleft.setFont(f);
		lbid.setFont(f);
		getContentPane().add(lbid);
		lbid.setBounds(40, 20, 70, 20);
		lbreaderid.setFont(f);
		getContentPane().add(lbreaderid);
		lbreaderid.setBounds(40, 50, 70, 20);
		lbbookid.setFont(f);
		getContentPane().add(lbbookid);
		lbbookid.setBounds(40, 80, 70, 20);
		lbrdate.setFont(f);
		getContentPane().add(lbrdate);
		lbrdate.setBounds(40, 110, 70, 20);
		getContentPane().add(tid);
		tid.setBounds(155, 20, 100, 23);
		getContentPane().add(treaderid);
		treaderid.setBounds(155, 50, 100, 23);
		getContentPane().add(tbookid);
		tbookid.setBounds(155, 80, 100, 23);
		getContentPane().add(trdate);
		trdate.setBounds(155, 110, 100, 23);
		btright.setFont(f);
		getContentPane().add(btright);
		btright.setBounds(330, 250, 50, 20);
		btleft.setFont(f);
		getContentPane().add(btleft);
		btleft.setBounds(330, 230, 50, 20);
		btdelet.setFont(f);
		getContentPane().add(btdelet);
		btdelet.setBounds(250, 240, 70, 25);
		btamend.setFont(f);
		getContentPane().add(btamend);
		btamend.setBounds(170, 240, 70, 25);
		btsave.setFont(f);
		getContentPane().add(btsave);
		btsave.setBounds(10, 240, 70, 25);
		btadd.setFont(f);
		getContentPane().add(btadd);
		btadd.setBounds(90, 240, 70, 25);
		setBounds(0, 0, 403, 329);
		Database.joinDB();
		String sqlc = "select * from ret";
		try {
			if (Database.query(sqlc)) {
				Database.rs.next();
				tid.setEditable(false);
				String id = ("" + Database.rs.getInt("id"));
				String readerid = Database.rs.getString("readerid");
				String bookid = Database.rs.getString("bookid");
				String rdate = Database.rs.getString("rdate");
				tid.setText(id);
				treaderid.setText(readerid);
				tbookid.setText(bookid);
				trdate.setText(rdate);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		btright.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (Database.rs.previous()) {
						String id = ("" + Database.rs.getInt("id"));
						String readerid = Database.rs.getString("readerid");
						String bookid = Database.rs.getString("bookid");
						String rdate = Database.rs.getString("rdate");
						tid.setEditable(false);
						tid.setText(id);
						treaderid.setText(readerid);
						tbookid.setText(bookid);
						trdate.setText(rdate);
					}
				} catch (Exception el) {
					System.out.println(el);
				}
			}
		});
		btleft.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (Database.rs.next()) {
						String id = ("" + Database.rs.getInt("id"));
						String readerid = Database.rs.getString("readerid");
						String bookid = Database.rs.getString("bookid");
						String rdate = Database.rs.getString("rdate");
						tid.setEditable(false);
						tid.setText(id);
						treaderid.setText(readerid);
						tbookid.setText(bookid);
						trdate.setText(rdate);
					}
				} catch (Exception el) {
					System.out.println(el);
				}
			}
		});
		btadd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btsave.setEnabled(true);
				tid.setEditable(false);
				tid.setText("");
				treaderid.setText("");
				tbookid.setText("");
				trdate.setText("");
			}
		});
		btsave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (treaderid.getText().equals("") || tbookid.getText().equals("") || trdate.getText().equals("")) {
					new JOptionPane().showMessageDialog(null, "������Ϣ������Ϊ�գ�");
				} else {
					String readerid = treaderid.getText();
					String bookid = tbookid.getText();
					String rdate = trdate.getText();
					String sInsert = "insert ret (readerid, bookid, rdate) values('" + readerid + "','" + bookid + "','"
							+ rdate + "')";
					try {
						if (Database.executeSQL(sInsert)) {
							btsave.setEnabled(false);
							new JOptionPane().showMessageDialog(null, "�������ݳɹ���");
							Database.joinDB();
							String sql = "select * from ret";
							Database.query(sql);
							Database.rs.last();
							String id1 = ("" + Database.rs.getInt("id"));
							String readerid1 = Database.rs.getString("readerid");
							String bookid1 = Database.rs.getString("bookid");
							String rdate1 = Database.rs.getString("rdate");
							tid.setEditable(false);
							tid.setText(id1);
							treaderid.setText(readerid1);
							tbookid.setText(bookid1);
							trdate.setText(rdate1);
						} else {
							new JOptionPane().showMessageDialog(null, "�������ݲ��ɹ���");
						}
					} catch (Exception ei) {
						new JOptionPane().showMessageDialog(null, "�������ݲ��ɹ���");
					}
				}
			}
		});
		btdelet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String sql = "delete from ret where id ='" + tid.getText() + "'";
					if (Database.executeSQL(sql)) {
						new JOptionPane().showMessageDialog(null, "����ɾ���ɹ���");
						Database.joinDB();
						String sqll = "select * from ret";
						Database.query(sqll);
						Database.rs.last();
						String id = ("" + Database.rs.getInt("id"));
						String readerid = Database.rs.getString("readerid");
						String bookid = Database.rs.getString("bookid");
						String rdate = Database.rs.getString("rdate");
						tid.setEditable(false);
						tid.setText(id);
						treaderid.setText(readerid);
						tbookid.setText(bookid);
						trdate.setText(rdate);
					}
				} catch (Exception el) {
				}
			}
		});
		btamend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String supdate = "update ret set readerid='" + treaderid.getText() + "',bookid='"
							+ tbookid.getText() + "',rdate='" + trdate.getText() + "' where id='" + tid.getText() + "'";
					if (Database.executeSQL(supdate)) {
						new JOptionPane().showMessageDialog(null, "�����޸ĳɹ���");
						Database.joinDB();
						String sqll = "select * from ret";
						Database.query(sqll);
						Database.rs.last();
						String id = ("" + Database.rs.getInt("id"));
						String readerid = Database.rs.getString("readerid");
						String bookid = Database.rs.getString("bookid");
						String rdate = Database.rs.getString("rdate");
						tid.setText(id);
						treaderid.setText(readerid);
						tbookid.setText(bookid);
						trdate.setText(rdate);
					}
				} catch (Exception es) {
				}
			}
		});
		this.setClosable(true);
		setVisible(true);
	}
}