package book;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import book.db.Database;

import java.sql.*;

public class ReaderManage extends JInternalFrame {
	JLabel lbid = new JLabel("ID��");
	JLabel lbname = new JLabel("������");
	JLabel lbtel = new JLabel("�绰��");
	JTextField tid = new JTextField();
	JTextField tname = new JTextField();
	JTextField ttel = new JTextField();
	JButton btright = new JButton("<<");
	JButton btleft = new JButton(">>");
	JButton btdelet = new JButton("ɾ��");
	JButton btamend = new JButton("�޸�");
	JButton btsave = new JButton("����");
	JButton btadd = new JButton("����");

	public ReaderManage() {
		setTitle("���߹���!");
		btsave.setEnabled(false);
		getContentPane().setLayout(null);
		Font f = new Font("������", 0, 14);
		btleft.setFont(f);
		lbid.setFont(f);
		getContentPane().add(lbid);
		lbid.setBounds(40, 20, 70, 20);
		lbname.setFont(f);
		getContentPane().add(lbname);
		lbname.setBounds(40, 50, 70, 20);
		lbtel.setFont(f);
		getContentPane().add(lbtel);
		lbtel.setBounds(40, 80, 70, 20);
		getContentPane().add(tid);
		tid.setBounds(155, 20, 100, 23);
		getContentPane().add(tname);
		tname.setBounds(155, 50, 100, 23);
		getContentPane().add(ttel);
		ttel.setBounds(155, 80, 100, 23);
		btright.setFont(f);
		getContentPane().add(btright);
		btright.setBounds(330, 250, 50, 20);
		btleft.setFont(f);
		getContentPane().add(btleft);
		btleft.setBounds(330, 230, 50, 20);
		btdelet.setFont(f);
		getContentPane().add(btdelet);
		btdelet.setBounds(250, 240, 70, 25);
		btamend.setFont(f);
		getContentPane().add(btamend);
		btamend.setBounds(170, 240, 70, 25);
		btsave.setFont(f);
		getContentPane().add(btsave);
		btsave.setBounds(10, 240, 70, 25);
		btadd.setFont(f);
		getContentPane().add(btadd);
		btadd.setBounds(90, 240, 70, 25);
		setBounds(0, 0, 403, 329);
		Database.joinDB();
		String sqlc = "select * from reader";
		try {
			if (Database.query(sqlc)) {
				Database.rs.next();
				tid.setEditable(false);
				String id = ("" + Database.rs.getInt("id"));
				String name = Database.rs.getString("name");
				String tel = Database.rs.getString("tel");
				tid.setText(id);
				tname.setText(name);
				ttel.setText(tel);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		btright.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (Database.rs.previous()) {
						String id = ("" + Database.rs.getInt("id"));
						String name = Database.rs.getString("name");
						String tel = Database.rs.getString("tel");
						tid.setEditable(false);
						tid.setText(id);
						tname.setText(name);
						ttel.setText(tel);
					}
				} catch (Exception el) {
					System.out.println(el);
				}
			}
		});
		btleft.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (Database.rs.next()) {
						String id = ("" + Database.rs.getInt("id"));
						String name = Database.rs.getString("name");
						String tel = Database.rs.getString("tel");
						tid.setEditable(false);
						tid.setText(id);
						tname.setText(name);
						ttel.setText(tel);
					}
				} catch (Exception el) {
					System.out.println(el);
				}
			}
		});
		btadd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btsave.setEnabled(true);
				tid.setEditable(false);
				tid.setText("");
				tname.setText("");
				ttel.setText("");
			}
		});
		btsave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tname.getText().equals("") || ttel.getText().equals("")) {
					new JOptionPane().showMessageDialog(null, "������Ϣ������Ϊ�գ�");
				} else {
					String name = tname.getText();
					String tel = ttel.getText();
					String sInsert = "insert reader (name, tel) values('" + name + "','" + tel + "')";
					try {
						if (Database.executeSQL(sInsert)) {
							btsave.setEnabled(false);
							new JOptionPane().showMessageDialog(null, "�������ݳɹ���");
							Database.joinDB();
							String sql = "select * from reader";
							Database.query(sql);
							Database.rs.last();
							String id1 = ("" + Database.rs.getInt("id"));
							String name1 = Database.rs.getString("name");
							String tel1 = Database.rs.getString("tel");
							tid.setEditable(false);
							tid.setText(id1);
							tname.setText(name1);
							ttel.setText(tel1);
						} else {
							new JOptionPane().showMessageDialog(null, "�������ݲ��ɹ���");
						}
					} catch (Exception ei) {
						new JOptionPane().showMessageDialog(null, "�������ݲ��ɹ���");
					}
				}
			}
		});
		btdelet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String sql = "delete from reader where id ='" + tid.getText() + "'";
					if (Database.executeSQL(sql)) {
						new JOptionPane().showMessageDialog(null, "����ɾ���ɹ���");
						Database.joinDB();
						String sqll = "select * from reader";
						Database.query(sqll);
						Database.rs.last();
						String id = ("" + Database.rs.getInt("id"));
						String name = Database.rs.getString("name");
						String tel = Database.rs.getString("tel");
						tid.setEditable(false);
						tid.setText(id);
						tname.setText(name);
						ttel.setText(tel);
					}
				} catch (Exception el) {
				}
			}
		});
		btamend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String supdate = "update reader set name='" + tname.getText() + "',tel='" + ttel.getText()
							+ "' where id='" + tid.getText() + "'";
					if (Database.executeSQL(supdate)) {
						new JOptionPane().showMessageDialog(null, "�����޸ĳɹ���");
						Database.joinDB();
						String sqll = "select * from reader";
						Database.query(sqll);
						Database.rs.last();
						String id = ("" + Database.rs.getInt("id"));
						String name = Database.rs.getString("name");
						String tel = Database.rs.getString("tel");
						tid.setText(id);
						tname.setText(name);
						ttel.setText(tel);
					}
				} catch (Exception es) {
				}
			}
		});
		this.setClosable(true);
		setVisible(true);
	}
}