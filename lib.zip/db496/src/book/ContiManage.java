package book;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import book.db.Database;

import java.sql.*;

public class ContiManage extends JInternalFrame {
	JLabel lbid = new JLabel("ID��");
	JLabel lbreaderid = new JLabel("���߱�ţ�");
	JLabel lbbookid = new JLabel("ͼ���ţ�");
	JLabel lbcontdate = new JLabel("�������ڣ�");
	JTextField tid = new JTextField();
	JTextField treaderid = new JTextField();
	JTextField tbookid = new JTextField();
	JTextField tcontdate = new JTextField();
	JButton btright = new JButton("<<");
	JButton btleft = new JButton(">>");
	JButton btdelet = new JButton("ɾ��");
	JButton btamend = new JButton("�޸�");
	JButton btsave = new JButton("����");
	JButton btadd = new JButton("����");

	public ContiManage() {
		setTitle("�������!");
		btsave.setEnabled(false);
		getContentPane().setLayout(null);
		Font f = new Font("������", 0, 14);
		btleft.setFont(f);
		lbid.setFont(f);
		getContentPane().add(lbid);
		lbid.setBounds(40, 20, 70, 20);
		lbreaderid.setFont(f);
		getContentPane().add(lbreaderid);
		lbreaderid.setBounds(40, 50, 70, 20);
		lbbookid.setFont(f);
		getContentPane().add(lbbookid);
		lbbookid.setBounds(40, 80, 70, 20);
		lbcontdate.setFont(f);
		getContentPane().add(lbcontdate);
		lbcontdate.setBounds(40, 110, 70, 20);
		getContentPane().add(tid);
		tid.setBounds(155, 20, 100, 23);
		getContentPane().add(treaderid);
		treaderid.setBounds(155, 50, 100, 23);
		getContentPane().add(tbookid);
		tbookid.setBounds(155, 80, 100, 23);
		getContentPane().add(tcontdate);
		tcontdate.setBounds(155, 110, 100, 23);
		btright.setFont(f);
		getContentPane().add(btright);
		btright.setBounds(330, 250, 50, 20);
		btleft.setFont(f);
		getContentPane().add(btleft);
		btleft.setBounds(330, 230, 50, 20);
		btdelet.setFont(f);
		getContentPane().add(btdelet);
		btdelet.setBounds(250, 240, 70, 25);
		btamend.setFont(f);
		getContentPane().add(btamend);
		btamend.setBounds(170, 240, 70, 25);
		btsave.setFont(f);
		getContentPane().add(btsave);
		btsave.setBounds(10, 240, 70, 25);
		btadd.setFont(f);
		getContentPane().add(btadd);
		btadd.setBounds(90, 240, 70, 25);
		setBounds(0, 0, 403, 329);
		Database.joinDB();
		String sqlc = "select * from conti";
		try {
			if (Database.query(sqlc)) {
				Database.rs.next();
				tid.setEditable(false);
				String id = ("" + Database.rs.getInt("id"));
				String readerid = Database.rs.getString("readerid");
				String bookid = Database.rs.getString("bookid");
				String contdate = Database.rs.getString("contdate");
				tid.setText(id);
				treaderid.setText(readerid);
				tbookid.setText(bookid);
				tcontdate.setText(contdate);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		btright.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (Database.rs.previous()) {
						String id = ("" + Database.rs.getInt("id"));
						String readerid = Database.rs.getString("readerid");
						String bookid = Database.rs.getString("bookid");
						String contdate = Database.rs.getString("contdate");
						tid.setEditable(false);
						tid.setText(id);
						treaderid.setText(readerid);
						tbookid.setText(bookid);
						tcontdate.setText(contdate);
					}
				} catch (Exception el) {
					System.out.println(el);
				}
			}
		});
		btleft.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (Database.rs.next()) {
						String id = ("" + Database.rs.getInt("id"));
						String readerid = Database.rs.getString("readerid");
						String bookid = Database.rs.getString("bookid");
						String contdate = Database.rs.getString("contdate");
						tid.setEditable(false);
						tid.setText(id);
						treaderid.setText(readerid);
						tbookid.setText(bookid);
						tcontdate.setText(contdate);
					}
				} catch (Exception el) {
					System.out.println(el);
				}
			}
		});
		btadd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btsave.setEnabled(true);
				tid.setEditable(false);
				tid.setText("");
				treaderid.setText("");
				tbookid.setText("");
				tcontdate.setText("");
			}
		});
		btsave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (treaderid.getText().equals("") || tbookid.getText().equals("") || tcontdate.getText().equals("")) {
					new JOptionPane().showMessageDialog(null, "������Ϣ������Ϊ�գ�");
				} else {
					String readerid = treaderid.getText();
					String bookid = tbookid.getText();
					String contdate = tcontdate.getText();
					String sInsert = "insert conti (readerid, bookid, contdate) values('" + readerid + "','" + bookid
							+ "','" + contdate + "')";
					try {
						if (Database.executeSQL(sInsert)) {
							btsave.setEnabled(false);
							new JOptionPane().showMessageDialog(null, "�������ݳɹ���");
							Database.joinDB();
							String sql = "select * from conti";
							Database.query(sql);
							Database.rs.last();
							String id1 = ("" + Database.rs.getInt("id"));
							String readerid1 = Database.rs.getString("readerid");
							String bookid1 = Database.rs.getString("bookid");
							String contdate1 = Database.rs.getString("contdate");
							tid.setEditable(false);
							tid.setText(id1);
							treaderid.setText(readerid1);
							tbookid.setText(bookid1);
							tcontdate.setText(contdate1);
						} else {
							new JOptionPane().showMessageDialog(null, "�������ݲ��ɹ���");
						}
					} catch (Exception ei) {
						new JOptionPane().showMessageDialog(null, "�������ݲ��ɹ���");
					}
				}
			}
		});
		btdelet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String sql = "delete from conti where id ='" + tid.getText() + "'";
					if (Database.executeSQL(sql)) {
						new JOptionPane().showMessageDialog(null, "����ɾ���ɹ���");
						Database.joinDB();
						String sqll = "select * from conti";
						Database.query(sqll);
						Database.rs.last();
						String id = ("" + Database.rs.getInt("id"));
						String readerid = Database.rs.getString("readerid");
						String bookid = Database.rs.getString("bookid");
						String contdate = Database.rs.getString("contdate");
						tid.setEditable(false);
						tid.setText(id);
						treaderid.setText(readerid);
						tbookid.setText(bookid);
						tcontdate.setText(contdate);
					}
				} catch (Exception el) {
				}
			}
		});
		btamend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String supdate = "update conti set readerid='" + treaderid.getText() + "',bookid='"
							+ tbookid.getText() + "',contdate='" + tcontdate.getText() + "' where id='" + tid.getText()
							+ "'";
					if (Database.executeSQL(supdate)) {
						new JOptionPane().showMessageDialog(null, "�����޸ĳɹ���");
						Database.joinDB();
						String sqll = "select * from conti";
						Database.query(sqll);
						Database.rs.last();
						String id = ("" + Database.rs.getInt("id"));
						String readerid = Database.rs.getString("readerid");
						String bookid = Database.rs.getString("bookid");
						String contdate = Database.rs.getString("contdate");
						tid.setText(id);
						treaderid.setText(readerid);
						tbookid.setText(bookid);
						tcontdate.setText(contdate);
					}
				} catch (Exception es) {
				}
			}
		});
		this.setClosable(true);
		setVisible(true);
	}
}