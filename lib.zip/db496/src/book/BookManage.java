package book;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import book.db.Database;

import java.sql.*;

public class BookManage extends JInternalFrame {
	JLabel lbid = new JLabel("ID��");
	JLabel lbbno = new JLabel("��ţ�");
	JLabel lbname = new JLabel("���ƣ�");
	JLabel lbtyp = new JLabel("���");
	JLabel lbpub = new JLabel("�����磺");
	JLabel lbnum = new JLabel("������");
	JTextField tid = new JTextField();
	JTextField tbno = new JTextField();
	JTextField tname = new JTextField();
	JTextField ttyp = new JTextField();
	JTextField tpub = new JTextField();
	JTextField tnum = new JTextField();
	JButton btright = new JButton("<<");
	JButton btleft = new JButton(">>");
	JButton btdelet = new JButton("ɾ��");
	JButton btamend = new JButton("�޸�");
	JButton btsave = new JButton("����");
	JButton btadd = new JButton("����");

	public BookManage() {
		setTitle("ͼ�����!");
		btsave.setEnabled(false);
		getContentPane().setLayout(null);
		Font f = new Font("������", 0, 14);
		btleft.setFont(f);
		lbid.setFont(f);
		getContentPane().add(lbid);
		lbid.setBounds(40, 20, 70, 20);
		lbbno.setFont(f);
		getContentPane().add(lbbno);
		lbbno.setBounds(40, 50, 70, 20);
		lbname.setFont(f);
		getContentPane().add(lbname);
		lbname.setBounds(40, 80, 70, 20);
		lbtyp.setFont(f);
		getContentPane().add(lbtyp);
		lbtyp.setBounds(40, 110, 70, 20);
		lbpub.setFont(f);
		getContentPane().add(lbpub);
		lbpub.setBounds(40, 140, 70, 20);
		lbnum.setFont(f);
		getContentPane().add(lbnum);
		lbnum.setBounds(40, 170, 70, 20);
		getContentPane().add(tid);
		tid.setBounds(155, 20, 100, 23);
		getContentPane().add(tbno);
		tbno.setBounds(155, 50, 100, 23);
		getContentPane().add(tname);
		tname.setBounds(155, 80, 100, 23);
		getContentPane().add(ttyp);
		ttyp.setBounds(155, 110, 100, 23);
		getContentPane().add(tpub);
		tpub.setBounds(155, 140, 100, 23);
		getContentPane().add(tnum);
		tnum.setBounds(155, 170, 100, 23);
		btright.setFont(f);
		getContentPane().add(btright);
		btright.setBounds(330, 250, 50, 20);
		btleft.setFont(f);
		getContentPane().add(btleft);
		btleft.setBounds(330, 230, 50, 20);
		btdelet.setFont(f);
		getContentPane().add(btdelet);
		btdelet.setBounds(250, 240, 70, 25);
		btamend.setFont(f);
		getContentPane().add(btamend);
		btamend.setBounds(170, 240, 70, 25);
		btsave.setFont(f);
		getContentPane().add(btsave);
		btsave.setBounds(10, 240, 70, 25);
		btadd.setFont(f);
		getContentPane().add(btadd);
		btadd.setBounds(90, 240, 70, 25);
		setBounds(0, 0, 403, 329);
		Database.joinDB();
		String sqlc = "select * from book";
		try {
			if (Database.query(sqlc)) {
				Database.rs.next();
				tid.setEditable(false);
				String id = ("" + Database.rs.getInt("id"));
				String bno = Database.rs.getString("bno");
				String name = Database.rs.getString("name");
				String typ = Database.rs.getString("typ");
				String pub = Database.rs.getString("pub");
				String num = Database.rs.getString("num");
				tid.setText(id);
				tbno.setText(bno);
				tname.setText(name);
				ttyp.setText(typ);
				tpub.setText(pub);
				tnum.setText(num);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		btright.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (Database.rs.previous()) {
						String id = ("" + Database.rs.getInt("id"));
						String bno = Database.rs.getString("bno");
						String name = Database.rs.getString("name");
						String typ = Database.rs.getString("typ");
						String pub = Database.rs.getString("pub");
						String num = Database.rs.getString("num");
						tid.setEditable(false);
						tid.setText(id);
						tbno.setText(bno);
						tname.setText(name);
						ttyp.setText(typ);
						tpub.setText(pub);
						tnum.setText(num);
					}
				} catch (Exception el) {
					System.out.println(el);
				}
			}
		});
		btleft.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (Database.rs.next()) {
						String id = ("" + Database.rs.getInt("id"));
						String bno = Database.rs.getString("bno");
						String name = Database.rs.getString("name");
						String typ = Database.rs.getString("typ");
						String pub = Database.rs.getString("pub");
						String num = Database.rs.getString("num");
						tid.setEditable(false);
						tid.setText(id);
						tbno.setText(bno);
						tname.setText(name);
						ttyp.setText(typ);
						tpub.setText(pub);
						tnum.setText(num);
					}
				} catch (Exception el) {
					System.out.println(el);
				}
			}
		});
		btadd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btsave.setEnabled(true);
				tid.setEditable(false);
				tid.setText("");
				tbno.setText("");
				tname.setText("");
				ttyp.setText("");
				tpub.setText("");
				tnum.setText("");
			}
		});
		btsave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tbno.getText().equals("") || tname.getText().equals("") || ttyp.getText().equals("")
						|| tpub.getText().equals("") || tnum.getText().equals("")) {
					new JOptionPane().showMessageDialog(null, "������Ϣ������Ϊ�գ�");
				} else {
					String bno = tbno.getText();
					String name = tname.getText();
					String typ = ttyp.getText();
					String pub = tpub.getText();
					String num = tnum.getText();
					String sInsert = "insert book (bno, name, typ, pub, num) values('" + bno + "','" + name + "','"
							+ typ + "','" + pub + "','" + num + "')";
					try {
						if (Database.executeSQL(sInsert)) {
							btsave.setEnabled(false);
							new JOptionPane().showMessageDialog(null, "�������ݳɹ���");
							Database.joinDB();
							String sql = "select * from book";
							Database.query(sql);
							Database.rs.last();
							String id1 = ("" + Database.rs.getInt("id"));
							String bno1 = Database.rs.getString("bno");
							String name1 = Database.rs.getString("name");
							String typ1 = Database.rs.getString("typ");
							String pub1 = Database.rs.getString("pub");
							String num1 = Database.rs.getString("num");
							tid.setEditable(false);
							tid.setText(id1);
							tbno.setText(bno1);
							tname.setText(name1);
							ttyp.setText(typ1);
							tpub.setText(pub1);
							tnum.setText(num1);
						} else {
							new JOptionPane().showMessageDialog(null, "�������ݲ��ɹ���");
						}
					} catch (Exception ei) {
						new JOptionPane().showMessageDialog(null, "�������ݲ��ɹ���");
					}
				}
			}
		});
		btdelet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String sql = "delete from book where id ='" + tid.getText() + "'";
					if (Database.executeSQL(sql)) {
						new JOptionPane().showMessageDialog(null, "����ɾ���ɹ���");
						Database.joinDB();
						String sqll = "select * from book";
						Database.query(sqll);
						Database.rs.last();
						String id = ("" + Database.rs.getInt("id"));
						String bno = Database.rs.getString("bno");
						String name = Database.rs.getString("name");
						String typ = Database.rs.getString("typ");
						String pub = Database.rs.getString("pub");
						String num = Database.rs.getString("num");
						tid.setEditable(false);
						tid.setText(id);
						tbno.setText(bno);
						tname.setText(name);
						ttyp.setText(typ);
						tpub.setText(pub);
						tnum.setText(num);
					}
				} catch (Exception el) {
				}
			}
		});
		btamend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String supdate = "update book set bno='" + tbno.getText() + "',name='" + tname.getText() + "',typ='"
							+ ttyp.getText() + "',pub='" + tpub.getText() + "',num='" + tnum.getText() + "' where id='"
							+ tid.getText() + "'";
					if (Database.executeSQL(supdate)) {
						new JOptionPane().showMessageDialog(null, "�����޸ĳɹ���");
						Database.joinDB();
						String sqll = "select * from book";
						Database.query(sqll);
						Database.rs.last();
						String id = ("" + Database.rs.getInt("id"));
						String bno = Database.rs.getString("bno");
						String name = Database.rs.getString("name");
						String typ = Database.rs.getString("typ");
						String pub = Database.rs.getString("pub");
						String num = Database.rs.getString("num");
						tid.setText(id);
						tbno.setText(bno);
						tname.setText(name);
						ttyp.setText(typ);
						tpub.setText(pub);
						tnum.setText(num);
					}
				} catch (Exception es) {
				}
			}
		});
		this.setClosable(true);
		setVisible(true);
	}
}