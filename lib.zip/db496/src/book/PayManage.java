package book;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import book.db.Database;

import java.sql.*;

public class PayManage extends JInternalFrame {
	JLabel lbid = new JLabel("ID��");
	JLabel lbreaderid = new JLabel("���߱�ţ�");
	JLabel lbbookid = new JLabel("ͼ���ţ�");
	JLabel lbamt = new JLabel("�����");
	JLabel lbpaydate = new JLabel("�տ����ڣ�");
	JLabel lbpayamt = new JLabel("�տ��");
	JTextField tid = new JTextField();
	JTextField treaderid = new JTextField();
	JTextField tbookid = new JTextField();
	JTextField tamt = new JTextField();
	JTextField tpaydate = new JTextField();
	JTextField tpayamt = new JTextField();
	JButton btright = new JButton("<<");
	JButton btleft = new JButton(">>");
	JButton btdelet = new JButton("ɾ��");
	JButton btamend = new JButton("�޸�");
	JButton btsave = new JButton("����");
	JButton btadd = new JButton("����");

	public PayManage() {
		setTitle("�տ����!");
		btsave.setEnabled(false);
		getContentPane().setLayout(null);
		Font f = new Font("������", 0, 14);
		btleft.setFont(f);
		lbid.setFont(f);
		getContentPane().add(lbid);
		lbid.setBounds(40, 20, 70, 20);
		lbreaderid.setFont(f);
		getContentPane().add(lbreaderid);
		lbreaderid.setBounds(40, 50, 70, 20);
		lbbookid.setFont(f);
		getContentPane().add(lbbookid);
		lbbookid.setBounds(40, 80, 70, 20);
		lbamt.setFont(f);
		getContentPane().add(lbamt);
		lbamt.setBounds(40, 110, 70, 20);
		lbpaydate.setFont(f);
		getContentPane().add(lbpaydate);
		lbpaydate.setBounds(40, 140, 70, 20);
		lbpayamt.setFont(f);
		getContentPane().add(lbpayamt);
		lbpayamt.setBounds(40, 170, 70, 20);
		getContentPane().add(tid);
		tid.setBounds(155, 20, 100, 23);
		getContentPane().add(treaderid);
		treaderid.setBounds(155, 50, 100, 23);
		getContentPane().add(tbookid);
		tbookid.setBounds(155, 80, 100, 23);
		getContentPane().add(tamt);
		tamt.setBounds(155, 110, 100, 23);
		getContentPane().add(tpaydate);
		tpaydate.setBounds(155, 140, 100, 23);
		getContentPane().add(tpayamt);
		tpayamt.setBounds(155, 170, 100, 23);
		btright.setFont(f);
		getContentPane().add(btright);
		btright.setBounds(330, 250, 50, 20);
		btleft.setFont(f);
		getContentPane().add(btleft);
		btleft.setBounds(330, 230, 50, 20);
		btdelet.setFont(f);
		getContentPane().add(btdelet);
		btdelet.setBounds(250, 240, 70, 25);
		btamend.setFont(f);
		getContentPane().add(btamend);
		btamend.setBounds(170, 240, 70, 25);
		btsave.setFont(f);
		getContentPane().add(btsave);
		btsave.setBounds(10, 240, 70, 25);
		btadd.setFont(f);
		getContentPane().add(btadd);
		btadd.setBounds(90, 240, 70, 25);
		setBounds(0, 0, 403, 329);
		Database.joinDB();
		String sqlc = "select * from pay";
		try {
			if (Database.query(sqlc)) {
				Database.rs.next();
				tid.setEditable(false);
				String id = ("" + Database.rs.getInt("id"));
				String readerid = Database.rs.getString("readerid");
				String bookid = Database.rs.getString("bookid");
				String amt = Database.rs.getString("amt");
				String paydate = Database.rs.getString("paydate");
				String payamt = Database.rs.getString("payamt");
				tid.setText(id);
				treaderid.setText(readerid);
				tbookid.setText(bookid);
				tamt.setText(amt);
				tpaydate.setText(paydate);
				tpayamt.setText(payamt);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		btright.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (Database.rs.previous()) {
						String id = ("" + Database.rs.getInt("id"));
						String readerid = Database.rs.getString("readerid");
						String bookid = Database.rs.getString("bookid");
						String amt = Database.rs.getString("amt");
						String paydate = Database.rs.getString("paydate");
						String payamt = Database.rs.getString("payamt");
						tid.setEditable(false);
						tid.setText(id);
						treaderid.setText(readerid);
						tbookid.setText(bookid);
						tamt.setText(amt);
						tpaydate.setText(paydate);
						tpayamt.setText(payamt);
					}
				} catch (Exception el) {
					System.out.println(el);
				}
			}
		});
		btleft.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (Database.rs.next()) {
						String id = ("" + Database.rs.getInt("id"));
						String readerid = Database.rs.getString("readerid");
						String bookid = Database.rs.getString("bookid");
						String amt = Database.rs.getString("amt");
						String paydate = Database.rs.getString("paydate");
						String payamt = Database.rs.getString("payamt");
						tid.setEditable(false);
						tid.setText(id);
						treaderid.setText(readerid);
						tbookid.setText(bookid);
						tamt.setText(amt);
						tpaydate.setText(paydate);
						tpayamt.setText(payamt);
					}
				} catch (Exception el) {
					System.out.println(el);
				}
			}
		});
		btadd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btsave.setEnabled(true);
				tid.setEditable(false);
				tid.setText("");
				treaderid.setText("");
				tbookid.setText("");
				tamt.setText("");
				tpaydate.setText("");
				tpayamt.setText("");
			}
		});
		btsave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (treaderid.getText().equals("") || tbookid.getText().equals("") || tamt.getText().equals("")
						|| tpaydate.getText().equals("") || tpayamt.getText().equals("")) {
					new JOptionPane().showMessageDialog(null, "������Ϣ������Ϊ�գ�");
				} else {
					String readerid = treaderid.getText();
					String bookid = tbookid.getText();
					String amt = tamt.getText();
					String paydate = tpaydate.getText();
					String payamt = tpayamt.getText();
					String sInsert = "insert pay (readerid, bookid, amt, paydate, payamt) values('" + readerid + "','"
							+ bookid + "','" + amt + "','" + paydate + "','" + payamt + "')";
					try {
						if (Database.executeSQL(sInsert)) {
							btsave.setEnabled(false);
							new JOptionPane().showMessageDialog(null, "�������ݳɹ���");
							Database.joinDB();
							String sql = "select * from pay";
							Database.query(sql);
							Database.rs.last();
							String id1 = ("" + Database.rs.getInt("id"));
							String readerid1 = Database.rs.getString("readerid");
							String bookid1 = Database.rs.getString("bookid");
							String amt1 = Database.rs.getString("amt");
							String paydate1 = Database.rs.getString("paydate");
							String payamt1 = Database.rs.getString("payamt");
							tid.setEditable(false);
							tid.setText(id1);
							treaderid.setText(readerid1);
							tbookid.setText(bookid1);
							tamt.setText(amt1);
							tpaydate.setText(paydate1);
							tpayamt.setText(payamt1);
						} else {
							new JOptionPane().showMessageDialog(null, "�������ݲ��ɹ���");
						}
					} catch (Exception ei) {
						new JOptionPane().showMessageDialog(null, "�������ݲ��ɹ���");
					}
				}
			}
		});
		btdelet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String sql = "delete from pay where id ='" + tid.getText() + "'";
					if (Database.executeSQL(sql)) {
						new JOptionPane().showMessageDialog(null, "����ɾ���ɹ���");
						Database.joinDB();
						String sqll = "select * from pay";
						Database.query(sqll);
						Database.rs.last();
						String id = ("" + Database.rs.getInt("id"));
						String readerid = Database.rs.getString("readerid");
						String bookid = Database.rs.getString("bookid");
						String amt = Database.rs.getString("amt");
						String paydate = Database.rs.getString("paydate");
						String payamt = Database.rs.getString("payamt");
						tid.setEditable(false);
						tid.setText(id);
						treaderid.setText(readerid);
						tbookid.setText(bookid);
						tamt.setText(amt);
						tpaydate.setText(paydate);
						tpayamt.setText(payamt);
					}
				} catch (Exception el) {
				}
			}
		});
		btamend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String supdate = "update pay set readerid='" + treaderid.getText() + "',bookid='"
							+ tbookid.getText() + "',amt='" + tamt.getText() + "',paydate='" + tpaydate.getText()
							+ "',payamt='" + tpayamt.getText() + "' where id='" + tid.getText() + "'";
					if (Database.executeSQL(supdate)) {
						new JOptionPane().showMessageDialog(null, "�����޸ĳɹ���");
						Database.joinDB();
						String sqll = "select * from pay";
						Database.query(sqll);
						Database.rs.last();
						String id = ("" + Database.rs.getInt("id"));
						String readerid = Database.rs.getString("readerid");
						String bookid = Database.rs.getString("bookid");
						String amt = Database.rs.getString("amt");
						String paydate = Database.rs.getString("paydate");
						String payamt = Database.rs.getString("payamt");
						tid.setText(id);
						treaderid.setText(readerid);
						tbookid.setText(bookid);
						tamt.setText(amt);
						tpaydate.setText(paydate);
						tpayamt.setText(payamt);
					}
				} catch (Exception es) {
				}
			}
		});
		this.setClosable(true);
		setVisible(true);
	}
}